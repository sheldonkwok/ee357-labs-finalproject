//SubWCRev: testfile.tmpl

char *Revision      = "6";
char *Modified      = "Modified";
char *BldTime       = "2010/06/10 11:38:56";
char *CommitDate    = "2010/06/09 19:10:42";
char *Range         = "2:6";
char *Mixed         = "Mixed revision WC";
char *URL           = "file:///K:/Sync Repo/r05.0_09_jun_2010_RPS_V9_1.2/trunk";

#if 1
#error Source is modified
#endif

// End of file


