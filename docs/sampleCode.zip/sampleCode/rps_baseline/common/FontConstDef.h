#ifndef FONT_CONST_DEF_H
    #define FONT_CONST_DEF_H

#define FIVE_DOT_SIZE                                        25  // estimated number of chars per line, temp until calc can be done
#define SIX_DOT_SIZE                                         25
#define SEVEN_DOT_SIZE                                       15
#define NINE_DOT_SIZE                                        15
#define TEN_DOT_SIZE                                         13
#define FIFTEEN_DOT_SIZE                                     11
#define EIGHTEEN_DOT_SIZE                                     7

#endif
