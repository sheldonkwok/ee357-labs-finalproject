#ifndef DEF_SDEXTGLOBALDECLAR_H
    #define DEF_SDEXTGLOBALDECLAR_H

extern                  File_iMn                     File1;
extern                  FilePtr                      FilePtr1;

#endif

