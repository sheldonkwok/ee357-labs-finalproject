#ifndef DEF_EXTSWITCHDECLAR_H
    #define DEF_EXTSWITCHDECLAR_H

extern                  SwStatusStruct               swStatusFlags;
extern                  SwStatusStructPtr            swStatusFlagsPtr;

#endif
