#ifndef DEF_EXTTIMEDECLAR_H
    #define DEF_EXTTIMEDECLAR_H

extern                  TimeDateStruct               SystemTimeTable;     

extern                  TimeDateStructPtr            SystemTimeTablePtr;

extern                  lcdTimeDateStaticStructPtr   lcdTimeDateStaticPtr;
extern                  lcdTimeDateStaticStruct      lcdTimeDateStatic;

extern                  lcdTimeDateDynStructPtr      lcdTimeDateDynPtr;
extern                  lcdTimeDateDynStruct         lcdTimeDateDyn;


#endif
