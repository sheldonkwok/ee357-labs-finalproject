//SubWCRev: testfile.tmpl

char *Revision      = "2";
char *Modified      = "Modified";
char *BldTime       = "2010/06/10 11:46:09";
char *CommitDate    = "2010/06/09 17:36:42";
char *Range         = "2";
char *Mixed         = "Not mixed";
char *URL           = "file:///K:/Sync Repo/r05.0_09_jun_2010_RPS_V9_1.2/trunk/common";

// End of file


